inputKTP_V8

PASTIKAN WEB BROWSER TERINSTALL
- Google Chrome Stable (x86_64)
- Firefox/Firefox ESR (x86_64)
- Microsoft Edge Stable (x86_64)

Tidak disarankan menggunakan versi Beta, Nightly, dan Dev

Sangat recommended menggunakan Firefox ESR, terutama di OS GNU+Linux


- semi modular function-based (belum pake class kyk oop ya..)
- selenium versi 4, jadi utk Edge pake fungsi Service bukan EdgeService
- pemilihan mode terminal/UI (mode terminal masih bug)
- pemilihan browser (Chrome/Firefox/Edge)
- auto looping akun di list akun.txt
- looping akun sampai semua akun selesai
- auto looping NIK di data_ktp_akun_gmail_com.txt
- looping NIK sampai stok tabung kosong
- log progress KTP terakhir diinput masing2 akun
- saat dijalankan membaca log NIK yg terakhir diinput masing2 akun, melanjutkan input ke KTP berikutnya
- backup log (masih bug)
- program berhenti ketika semua akun selesai, atau error/retry 5 x 3 detik
- logging message terminal (masih bug)


akun.txt
	akun.01@contoh.com,112233
	akun2@contoh.com,223344
	
data_ktp_akun_01_contoh_com.txt
data_ktp_akun2_contoh_com.txt

BUG (not working):
- verbose logging message terminal ke file log
- mode headless (tanpa UI)
- backup log_progress


